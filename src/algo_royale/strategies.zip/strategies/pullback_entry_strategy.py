import pandas as pd

from .base_strategy import Strategy


class PullbackEntryStrategy(Strategy):
    def __init__(self, ma_col="sma_20", close_col="close_price"):
        self.ma_col = ma_col
        self.close_col = close_col

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        above_ma = df[self.close_col] > df[self.ma_col]
        below_ma_yesterday = df[self.close_col].shift(1) < df[self.ma_col].shift(1)
        recovery = above_ma & below_ma_yesterday

        signals = pd.Series("hold", index=df.index, name="signal")
        signals[recovery] = "buy"
        signals[recovery.shift(-1).fillna(False)] = "sell"
        return signals
