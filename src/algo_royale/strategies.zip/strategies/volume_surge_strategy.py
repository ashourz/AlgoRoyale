import pandas as pd

from .base_strategy import Strategy


class VolumeSurgeStrategy(Strategy):
    def __init__(self, vol_col="volume", threshold=2.0, ma_window=20):
        self.vol_col = vol_col
        self.threshold = threshold
        self.ma_window = ma_window

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        vol_ma = df[self.vol_col].rolling(window=self.ma_window).mean()
        surge = df[self.vol_col] > (vol_ma * self.threshold)

        signals = pd.Series("hold", index=df.index, name="signal")
        signals[surge] = "buy"
        signals[surge.shift(-1).fillna(False)] = "sell"
        return signals
