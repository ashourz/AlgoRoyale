import pandas as pd

from algo_royale.strategies.base_strategy import Strategy


class ComboStrategy(Strategy):
    """
    Combo Strategy:
    This strategy combines RSI, MACD, and volume indicators to generate buy/sell signals.
    - Buy when RSI < 30, MACD > 0, and volume > 20-day moving average of volume.
    - Sell otherwise.
    - Hold if none of the conditions are met.
    """

    def __init__(
        self,
        rsi_col="rsi",
        macd_col="macd",
        volume_col="volume",
        vol_ma_col="vol_ma_20",
    ):
        self.rsi_col = rsi_col
        self.macd_col = macd_col
        self.volume_col = volume_col
        self.vol_ma_col = vol_ma_col

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        conditions = (
            (df[self.rsi_col] < 30)
            & (df[self.macd_col] > 0)
            & (df[self.volume_col] > df[self.vol_ma_col])
        )
        signals = pd.Series("hold", index=df.index, name="signal")
        signals[conditions] = "buy"
        signals[~conditions] = "sell"
        return signals
