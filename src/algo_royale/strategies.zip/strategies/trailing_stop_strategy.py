import pandas as pd

from .base_strategy import Strategy


class TrailingStopStrategy(Strategy):
    def __init__(self, close_col="close_price", stop_pct=0.02):
        self.close_col = close_col
        self.stop_pct = stop_pct

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        signals = pd.Series("hold", index=df.index, name="signal")
        in_position = False
        trailing_stop = None

        for i in range(len(df)):
            price = df.iloc[i][self.close_col]

            if not in_position:
                signals.iloc[i] = "buy"
                in_position = True
                trailing_stop = price * (1 - self.stop_pct)
            else:
                trailing_stop = max(trailing_stop, price * (1 - self.stop_pct))
                if price < trailing_stop:
                    signals.iloc[i] = "sell"
                    in_position = False

        return signals
