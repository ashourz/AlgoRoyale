import pandas as pd

from .base_strategy import Strategy


class TimeOfDayBiasStrategy(Strategy):
    """
    Time of Day Bias Strategy:
    - Buy at specific hours of the day.
    - Sell at different specific hours of the day.
    - Hold otherwise.
    """

    def __init__(self, buy_hours={10, 14}, sell_hours={11, 15}, hour_col="hour"):
        self.buy_hours = buy_hours
        self.sell_hours = sell_hours
        self.hour_col = hour_col

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        signals = pd.Series("hold", index=df.index, name="signal")
        signals[df[self.hour_col].isin(self.buy_hours)] = "buy"
        signals[df[self.hour_col].isin(self.sell_hours)] = "sell"
        return signals
